CREATE TABLE [SM_InsightHit_Week] (
		[InsightHitID]             [int] IDENTITY(1, 1) NOT NULL,
		[InsightHitPeriodFrom]     [datetime2](7) NOT NULL,
		[InsightHitPeriodTo]       [datetime2](7) NOT NULL,
		[InsightHitValue]          [bigint] NOT NULL,
		[InsightHitInsightID]      [int] NOT NULL
) 
ALTER TABLE [SM_InsightHit_Week]
	ADD
	CONSTRAINT [PK_SM_InsightHit_Week]
	PRIMARY KEY
	CLUSTERED
	([InsightHitID])
	
CREATE UNIQUE NONCLUSTERED INDEX [UQ_SM_InsightHit_Week_InsightHitInsightID_InsightHitPeriodFrom_InsightHitPeriodTo]
	ON [SM_InsightHit_Week] ([InsightHitInsightID], [InsightHitPeriodFrom], [InsightHitPeriodTo]) 

ALTER TABLE [SM_InsightHit_Week]
	WITH CHECK
	ADD CONSTRAINT [FK_SM_InsightHit_Week_SM_Insight_InsightHitInsightID]
	FOREIGN KEY ([InsightHitInsightID]) REFERENCES [SM_Insight] ([InsightID])
ALTER TABLE [SM_InsightHit_Week]
	CHECK CONSTRAINT [FK_SM_InsightHit_Week_SM_Insight_InsightHitInsightID]
