CREATE TABLE [CMS_AttachmentHistory] (
		[AttachmentHistoryID]         [int] IDENTITY(1, 1) NOT NULL,
		[AttachmentName]              [nvarchar](255) NOT NULL,
		[AttachmentExtension]         [nvarchar](50) NOT NULL,
		[AttachmentSize]              [int] NOT NULL,
		[AttachmentMimeType]          [nvarchar](100) NOT NULL,
		[AttachmentBinary]            [varbinary](max) NULL,
		[AttachmentImageWidth]        [int] NULL,
		[AttachmentImageHeight]       [int] NULL,
		[AttachmentDocumentID]        [int] NOT NULL,
		[AttachmentGUID]              [uniqueidentifier] NOT NULL,
		[AttachmentIsUnsorted]        [bit] NULL,
		[AttachmentOrder]             [int] NULL,
		[AttachmentGroupGUID]         [uniqueidentifier] NULL,
		[AttachmentHash]              [nvarchar](32) NULL,
		[AttachmentTitle]             [nvarchar](250) NULL,
		[AttachmentDescription]       [nvarchar](max) NULL,
		[AttachmentCustomData]        [nvarchar](max) NULL,
		[AttachmentLastModified]      [datetime2](7) NULL,
		[AttachmentHistoryGUID]       [uniqueidentifier] NOT NULL,
		[AttachmentSiteID]            [int] NULL,
		[AttachmentSearchContent]     [nvarchar](max) NULL
)  
ALTER TABLE [CMS_AttachmentHistory]
	ADD
	CONSTRAINT [PK_CMS_AttachmentHistory]
	PRIMARY KEY
	NONCLUSTERED
	([AttachmentHistoryID])
	
ALTER TABLE [CMS_AttachmentHistory]
	ADD
	CONSTRAINT [DEFAULT_CMS_AttachmentHistory_AttachmentHistoryGUID]
	DEFAULT ('00000000-0000-0000-0000-000000000000') FOR [AttachmentHistoryGUID]
CREATE CLUSTERED INDEX [IX_CMS_AttachmentHistory_AttachmentDocumentID_AttachmentName]
	ON [CMS_AttachmentHistory] ([AttachmentDocumentID], [AttachmentName]) 
CREATE NONCLUSTERED INDEX [IX_CMS_AttachmentHistory_AttachmentGUID]
	ON [CMS_AttachmentHistory] ([AttachmentGUID]) 
CREATE NONCLUSTERED INDEX [IX_CMS_AttachmentHistory_AttachmentIsUnsorted_AttachmentGroupGUID_AttachmentOrder]
	ON [CMS_AttachmentHistory] ([AttachmentIsUnsorted], [AttachmentGroupGUID], [AttachmentOrder]) 
CREATE NONCLUSTERED INDEX [IX_CMS_AttachmentHistory_AttachmentSiteID]
	ON [CMS_AttachmentHistory] ([AttachmentSiteID]) 

ALTER TABLE [CMS_AttachmentHistory]
	WITH CHECK
	ADD CONSTRAINT [FK_CMS_AttachmentHistory_AttachmentSiteID_CMS_Site]
	FOREIGN KEY ([AttachmentSiteID]) REFERENCES [CMS_Site] ([SiteID])
ALTER TABLE [CMS_AttachmentHistory]
	CHECK CONSTRAINT [FK_CMS_AttachmentHistory_AttachmentSiteID_CMS_Site]
