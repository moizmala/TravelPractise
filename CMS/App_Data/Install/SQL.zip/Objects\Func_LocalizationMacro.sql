-- Surrounds given nvarchar parameter with localization macro tags.
CREATE FUNCTION [Func_LocalizationMacro] (
 @localizationMacroKey NVARCHAR(MAX)
)  
RETURNS NVARCHAR(MAX) AS
BEGIN
	RETURN N'{$' + @localizationMacroKey + N'$}'
END
