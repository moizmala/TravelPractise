CREATE TABLE [SM_LinkedInAccount] (
		[LinkedInAccountID]                        [int] IDENTITY(1, 1) NOT NULL,
		[LinkedInAccountDisplayName]               [nvarchar](200) NOT NULL,
		[LinkedInAccountName]                      [nvarchar](200) NOT NULL,
		[LinkedInAccountIsDefault]                 [bit] NULL,
		[LinkedInAccountAccessToken]               [nvarchar](500) NOT NULL,
		[LinkedInAccountAccessTokenSecret]         [nvarchar](500) NOT NULL,
		[LinkedInAccountLastModified]              [datetime2](7) NOT NULL,
		[LinkedInAccountGUID]                      [uniqueidentifier] NOT NULL,
		[LinkedInAccountSiteID]                    [int] NOT NULL,
		[LinkedInAccountProfileID]                 [nvarchar](50) NOT NULL,
		[LinkedInAccountLinkedInApplicationID]     [int] NOT NULL,
		[LinkedInAccountProfileName]               [nvarchar](200) NULL,
		[LinkedInAccountAccessTokenExpiration]     [datetime2](7) NULL
) 
ALTER TABLE [SM_LinkedInAccount]
	ADD
	CONSTRAINT [PK_SM_LinkedInAccount]
	PRIMARY KEY
	CLUSTERED
	([LinkedInAccountID])
	
ALTER TABLE [SM_LinkedInAccount]
	ADD
	CONSTRAINT [DEFAULT_SM_LinkedInAccount_LinkedInAccountAccessToken]
	DEFAULT (N'') FOR [LinkedInAccountAccessToken]
ALTER TABLE [SM_LinkedInAccount]
	ADD
	CONSTRAINT [DEFAULT_SM_LinkedInAccount_LinkedInAccountAccessTokenSecret]
	DEFAULT (N'') FOR [LinkedInAccountAccessTokenSecret]
ALTER TABLE [SM_LinkedInAccount]
	ADD
	CONSTRAINT [DEFAULT_SM_LinkedInAccount_LinkedInAccountDisplayName]
	DEFAULT (N'') FOR [LinkedInAccountDisplayName]
ALTER TABLE [SM_LinkedInAccount]
	ADD
	CONSTRAINT [DEFAULT_SM_LinkedInAccount_LinkedInAccountGUID]
	DEFAULT ('00000000-0000-0000-0000-000000000000') FOR [LinkedInAccountGUID]
ALTER TABLE [SM_LinkedInAccount]
	ADD
	CONSTRAINT [DEFAULT_SM_LinkedInAccount_LinkedInAccountLinkedInApplicationID]
	DEFAULT ((0)) FOR [LinkedInAccountLinkedInApplicationID]
ALTER TABLE [SM_LinkedInAccount]
	ADD
	CONSTRAINT [DEFAULT_SM_LinkedInAccount_LinkedInAccountName]
	DEFAULT (N'') FOR [LinkedInAccountName]
ALTER TABLE [SM_LinkedInAccount]
	ADD
	CONSTRAINT [DEFAULT_SM_LinkedInAccount_LinkedInAccountProfileID]
	DEFAULT (N'') FOR [LinkedInAccountProfileID]
ALTER TABLE [SM_LinkedInAccount]
	ADD
	CONSTRAINT [DEFAULT_SM_LinkedInAccount_LinkedInAccountSiteID]
	DEFAULT ((0)) FOR [LinkedInAccountSiteID]

