CREATE TABLE [COM_TaxClass] (
		[TaxClassID]                   [int] IDENTITY(1, 1) NOT NULL,
		[TaxClassName]                 [nvarchar](200) NOT NULL,
		[TaxClassDisplayName]          [nvarchar](200) NOT NULL,
		[TaxClassZeroIfIDSupplied]     [bit] NULL,
		[TaxClassGUID]                 [uniqueidentifier] NOT NULL,
		[TaxClassLastModified]         [datetime2](7) NOT NULL,
		[TaxClassSiteID]               [int] NULL
) 
ALTER TABLE [COM_TaxClass]
	ADD
	CONSTRAINT [PK_COM_TaxClass]
	PRIMARY KEY
	NONCLUSTERED
	([TaxClassID])
	
ALTER TABLE [COM_TaxClass]
	ADD
	CONSTRAINT [DEFAULT_COM_TaxClass_TaxClassDisplayName]
	DEFAULT (N'') FOR [TaxClassDisplayName]
ALTER TABLE [COM_TaxClass]
	ADD
	CONSTRAINT [DEFAULT_COM_TaxClass_TaxClassGUID]
	DEFAULT ('00000000-0000-0000-0000-000000000000') FOR [TaxClassGUID]
ALTER TABLE [COM_TaxClass]
	ADD
	CONSTRAINT [DEFAULT_COM_TaxClass_TaxClassLastModified]
	DEFAULT ('9/20/2012 1:31:27 PM') FOR [TaxClassLastModified]
ALTER TABLE [COM_TaxClass]
	ADD
	CONSTRAINT [DEFAULT_COM_TaxClass_TaxClassName]
	DEFAULT (N'') FOR [TaxClassName]
ALTER TABLE [COM_TaxClass]
	ADD
	CONSTRAINT [DEFAULT_COM_TaxClass_TaxClassZeroIfIDSupplied]
	DEFAULT ((0)) FOR [TaxClassZeroIfIDSupplied]
CREATE CLUSTERED INDEX [IX_COM_TaxClass_TaxClassDisplayName]
	ON [COM_TaxClass] ([TaxClassDisplayName]) 
CREATE NONCLUSTERED INDEX [IX_COM_TaxClass_TaxClassSiteID]
	ON [COM_TaxClass] ([TaxClassSiteID]) 

ALTER TABLE [COM_TaxClass]
	WITH CHECK
	ADD CONSTRAINT [FK_COM_TaxClass_TaxClassSiteID_CMS_Site]
	FOREIGN KEY ([TaxClassSiteID]) REFERENCES [CMS_Site] ([SiteID])
ALTER TABLE [COM_TaxClass]
	CHECK CONSTRAINT [FK_COM_TaxClass_TaxClassSiteID_CMS_Site]
