CREATE TABLE [OM_MVTest] (
		[MVTestID]                       [int] IDENTITY(1, 1) NOT NULL,
		[MVTestName]                     [nvarchar](50) NOT NULL,
		[MVTestDescription]              [nvarchar](max) NULL,
		[MVTestPage]                     [nvarchar](450) NOT NULL,
		[MVTestSiteID]                   [int] NOT NULL,
		[MVTestCulture]                  [nvarchar](50) NULL,
		[MVTestOpenFrom]                 [datetime2](7) NULL,
		[MVTestOpenTo]                   [datetime2](7) NULL,
		[MVTestMaxConversions]           [int] NULL,
		[MVTestConversions]              [int] NULL,
		[MVTestTargetConversionType]     [nvarchar](100) NULL,
		[MVTestGUID]                     [uniqueidentifier] NOT NULL,
		[MVTestLastModified]             [datetime2](7) NOT NULL,
		[MVTestEnabled]                  [bit] NOT NULL,
		[MVTestDisplayName]              [nvarchar](100) NOT NULL
)  
ALTER TABLE [OM_MVTest]
	ADD
	CONSTRAINT [PK_OM_MVTest]
	PRIMARY KEY
	CLUSTERED
	([MVTestID])
	
ALTER TABLE [OM_MVTest]
	ADD
	CONSTRAINT [DEFAULT_OM_MVTest_MVTestDisplayName]
	DEFAULT ('') FOR [MVTestDisplayName]
ALTER TABLE [OM_MVTest]
	ADD
	CONSTRAINT [DEFAULT_OM_MVTest_MVTestEnabled]
	DEFAULT ((0)) FOR [MVTestEnabled]
ALTER TABLE [OM_MVTest]
	ADD
	CONSTRAINT [DEFAULT_OM_MVTest_MVTestName]
	DEFAULT ('') FOR [MVTestName]
ALTER TABLE [OM_MVTest]
	ADD
	CONSTRAINT [DEFAULT_OM_MVTest_MVTestPage]
	DEFAULT ('') FOR [MVTestPage]
ALTER TABLE [OM_MVTest]
	ADD
	CONSTRAINT [DEFAULT_OM_MVTest_MVTestSiteID]
	DEFAULT ((0)) FOR [MVTestSiteID]
ALTER TABLE [OM_MVTest]
	ADD
	CONSTRAINT [DEFAULT_OM_MVTest_MVTestTargetConversionType]
	DEFAULT ('TOTAL') FOR [MVTestTargetConversionType]
CREATE NONCLUSTERED INDEX [IX_OM_MVTest_MVTestSiteID]
	ON [OM_MVTest] ([MVTestSiteID]) 

ALTER TABLE [OM_MVTest]
	WITH CHECK
	ADD CONSTRAINT [FK_OM_MVTest_MVTestSiteID_CMS_Site]
	FOREIGN KEY ([MVTestSiteID]) REFERENCES [CMS_Site] ([SiteID])
ALTER TABLE [OM_MVTest]
	CHECK CONSTRAINT [FK_OM_MVTest_MVTestSiteID_CMS_Site]
