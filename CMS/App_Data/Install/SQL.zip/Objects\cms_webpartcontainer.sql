CREATE TABLE [CMS_WebPartContainer] (
		[ContainerID]               [int] IDENTITY(1, 1) NOT NULL,
		[ContainerDisplayName]      [nvarchar](200) NOT NULL,
		[ContainerName]             [nvarchar](200) NOT NULL,
		[ContainerTextBefore]       [nvarchar](max) NULL,
		[ContainerTextAfter]        [nvarchar](max) NULL,
		[ContainerGUID]             [uniqueidentifier] NOT NULL,
		[ContainerLastModified]     [datetime2](7) NOT NULL,
		[ContainerCSS]              [nvarchar](max) NULL
)  
ALTER TABLE [CMS_WebPartContainer]
	ADD
	CONSTRAINT [PK_CMS_WebPartContainer]
	PRIMARY KEY
	NONCLUSTERED
	([ContainerID])
	
ALTER TABLE [CMS_WebPartContainer]
	ADD
	CONSTRAINT [DEFAULT_CMS_WebPartContainer_ContainerDisplayName]
	DEFAULT ('') FOR [ContainerDisplayName]
ALTER TABLE [CMS_WebPartContainer]
	ADD
	CONSTRAINT [DEFAULT_CMS_WebPartContainer_ContainerName]
	DEFAULT ('') FOR [ContainerName]
CREATE CLUSTERED INDEX [IX_CMS_WebPartContainer_ContainerDisplayName]
	ON [CMS_WebPartContainer] ([ContainerDisplayName]) 
CREATE NONCLUSTERED INDEX [IX_CMS_WebPartContainer_ContainerName]
	ON [CMS_WebPartContainer] ([ContainerName]) 

