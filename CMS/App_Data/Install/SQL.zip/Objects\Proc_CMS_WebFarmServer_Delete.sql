CREATE PROCEDURE [Proc_CMS_WebFarmServer_Delete] 
@ID int
AS
BEGIN
	BEGIN TRANSACTION
		-- Remove all task - server binding
		DELETE FROM [CMS_WebFarmServerTask] WHERE ServerId = @ID;
		-- Remove server
		DELETE FROM [CMS_WebFarmServer] WHERE ServerId = @ID;
	COMMIT
	-- Remove all unasigned tasks
	DELETE FROM CMS_WebFarmTask WHERE TaskEnabled = 1 AND TaskIsAnonymous = 0 AND TaskID NOT IN (SELECT TaskID FROM CMS_WebFarmServerTask);
END
