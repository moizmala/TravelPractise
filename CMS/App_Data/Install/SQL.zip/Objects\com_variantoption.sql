CREATE TABLE [COM_VariantOption] (
		[VariantSKUID]     [int] NOT NULL,
		[OptionSKUID]      [int] NOT NULL
) 
ALTER TABLE [COM_VariantOption]
	ADD
	CONSTRAINT [PK_COM_VariantOption]
	PRIMARY KEY
	CLUSTERED
	([VariantSKUID], [OptionSKUID])
	
CREATE NONCLUSTERED INDEX [IX_COM_VariantOption_OptionSKUID]
	ON [COM_VariantOption] ([OptionSKUID]) 

ALTER TABLE [COM_VariantOption]
	WITH CHECK
	ADD CONSTRAINT [FK_COM_VariantOption_OptionSKUID_COM_SKU]
	FOREIGN KEY ([OptionSKUID]) REFERENCES [COM_SKU] ([SKUID])
ALTER TABLE [COM_VariantOption]
	CHECK CONSTRAINT [FK_COM_VariantOption_OptionSKUID_COM_SKU]
ALTER TABLE [COM_VariantOption]
	WITH CHECK
	ADD CONSTRAINT [FK_COM_VariantOption_VariantSKUID_COM_SKU]
	FOREIGN KEY ([VariantSKUID]) REFERENCES [COM_SKU] ([SKUID])
ALTER TABLE [COM_VariantOption]
	CHECK CONSTRAINT [FK_COM_VariantOption_VariantSKUID_COM_SKU]
