CREATE PROCEDURE [Proc_CMS_Class_GetXmlSchema]
	@ClassName nvarchar(100)
AS
BEGIN
	SELECT ClassXmlSchema, ClassTableName FROM [CMS_Class] WHERE ClassName = @ClassName
END
