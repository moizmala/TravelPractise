CREATE TABLE [SM_Insight] (
		[InsightID]             [int] IDENTITY(1, 1) NOT NULL,
		[InsightCodeName]       [nvarchar](200) NOT NULL,
		[InsightExternalID]     [nvarchar](max) NOT NULL,
		[InsightPeriodType]     [nvarchar](20) NOT NULL,
		[InsightValueName]      [nvarchar](max) NULL
)  
ALTER TABLE [SM_Insight]
	ADD
	CONSTRAINT [PK_SM_Insight]
	PRIMARY KEY
	CLUSTERED
	([InsightID])
	
ALTER TABLE [SM_Insight]
	ADD
	CONSTRAINT [DEFAULT_SM_Insight_InsightExternalID]
	DEFAULT ('') FOR [InsightExternalID]
CREATE NONCLUSTERED INDEX [IX_SM_Insight_InsightCodeName_InsightPeriodType]
	ON [SM_Insight] ([InsightCodeName], [InsightPeriodType]) 

