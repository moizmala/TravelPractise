CREATE PROCEDURE [Proc_OM_ScoreContactRule_AddContacts]
@ScoreID int,
@RuleID int,
@Value int,
@ContactIDs varchar(MAX)
AS
BEGIN
INSERT INTO OM_ScoreContactRule (ScoreID, ContactID, RuleID, Value)
  SELECT @ScoreID, ContactIDs.ItemID, @RuleID, @Value FROM 
    (SELECT ItemID FROM Func_Selection_ParseIDs(@contactIDs)) as ContactIDs
  WHERE ContactIDs.ItemID NOT IN (SELECT ContactID FROM OM_ScoreContactRule WHERE ScoreID=@ScoreID and ContactID=ContactIDs.ItemID and RuleID=@RuleID )
END
