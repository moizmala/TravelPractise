-- HFA-9 - SQL error when creating global category
GO
DECLARE @HOTFIXVERSION INT;
SET @HOTFIXVERSION = (SELECT [KeyValue] FROM [CMS_SettingsKey] WHERE [KeyName] = N'CMSHotfixVersion')
IF @HOTFIXVERSION < 1
BEGIN
UPDATE [CMS_Class]
SET [ClassFormDefinition]
= 
'<form version="2">
  <field column="CategoryID" columntype="integer" fieldtype="CustomUserControl" isPK="true" system="true" publicfield="false" guid="a7e6de80-6774-4fc9-8764-fde25832fce0" visibility="none" reftype="Required">
    <properties>
      <fieldcaption>CategoryID</fieldcaption>
    </properties>
    <settings>
      <controlname>labelcontrol</controlname>
    </settings>
  </field>
  <field column="CategorySiteID" visible="true" columntype="integer" fieldtype="CustomUserControl" allowempty="true" system="true" publicfield="false" guid="55f19a7f-1e83-4f11-8dcd-b15e2c5e2638" visibility="none" reftype="Required">
    <properties>
      <fielddescription>{$category.categorysiteid.description$}</fielddescription>
      <defaultvalue ismacro="true">{%Form.ObjectSiteID &gt; 0 ? Form.ObjectSiteID : "" @%}</defaultvalue>
      <fieldcaption>{$category_edit.categorysite$}</fieldcaption>
    </properties>
    <settings>
      <RepeatDirection>horizontal</RepeatDirection>
      <controlname>RadioButtonsControl</controlname>
      <RepeatLayout>Flow</RepeatLayout>
      <Options>{%Form.ObjectSiteID @%};{$category_edit.sitecategory$}
;{$category_edit.globalcategory$}</Options>
    </settings>
  </field>
  <field column="CategoryDisplayName" visible="true" columntype="text" fieldtype="CustomUserControl" system="true" columnsize="250" publicfield="false" guid="62f59aab-9b3e-4ddc-8f7a-fb97e039de40" visibility="none" translatefield="true" reftype="Required">
    <properties>
      <fielddescription>{$category.categorydisplayname.description$}</fielddescription>
      <fieldcaption>{$general.displayname$}</fieldcaption>
    </properties>
    <settings>
      <controlname>localizabletextbox</controlname>
      <ValueIsContent>False</ValueIsContent>
    </settings>
  </field>
  <field column="CategoryName" visible="true" columntype="text" fieldtype="CustomUserControl" allowempty="true" system="true" columnsize="250" publicfield="false" guid="6ec936dc-3b0f-476c-8d07-9dbb7e5a19b9" visibility="none" isunique="true" reftype="Required">
    <properties>
      <fielddescription>{$category.categoryname.description$}</fielddescription>
      <fieldcaption>{$general.codename$}</fieldcaption>
    </properties>
    <settings>
      <controlname>codename</controlname>
    </settings>
  </field>
  <field column="CategoryParentID" visible="true" columntype="integer" fieldtype="CustomUserControl" allowempty="true" system="true" publicfield="false" guid="70e95a64-6c83-4dc3-a334-c8a7bf61ea39" visibility="none" reftype="Required">
    <properties>
      <visiblemacro ismacro="true">{%FormMode == FormModeEnum.Update @%}</visiblemacro>
      <fielddescription>{$category.categoryparentid.description$}</fielddescription>
      <fieldcaption>{$category_edit.parentcategory$}</fieldcaption>
    </properties>
    <settings>
      <controlname>category_sparentselector</controlname>
      <AddRootRecord>True</AddRootRecord>
    </settings>
  </field>
  <field column="CategoryDescription" visible="true" columntype="longtext" fieldtype="CustomUserControl" allowempty="true" system="true" publicfield="false" guid="21b4dc27-69d2-4ee5-ad21-31ce7362a169" visibility="none" translatefield="true" reftype="Required">
    <properties>
      <fielddescription>{$category.categorydescription.description$}</fielddescription>
      <fieldcaption>{$general.description$}</fieldcaption>
    </properties>
    <settings>
      <AutoCompleteEnableCaching>False</AutoCompleteEnableCaching>
      <AutoCompleteShowOnlyCurrentWordInCompletionListItem>False</AutoCompleteShowOnlyCurrentWordInCompletionListItem>
      <Wrap>True</Wrap>
      <IsTextArea>True</IsTextArea>
      <AutoCompleteFirstRowSelected>False</AutoCompleteFirstRowSelected>
      <controlname>textareacontrol</controlname>
      <FilterMode>False</FilterMode>
    </settings>
  </field>
  <field column="CategoryEnabled" visible="true" columntype="boolean" fieldtype="CustomUserControl" system="true" publicfield="false" guid="60a19437-daca-476d-a9c7-f771810012d2" visibility="none" reftype="Required">
    <properties>
      <fielddescription>{$category.categoryenabled.description$}</fielddescription>
      <defaultvalue>True</defaultvalue>
      <fieldcaption>{$general.enabled$}</fieldcaption>
    </properties>
    <settings>
      <controlname>checkboxcontrol</controlname>
    </settings>
  </field>
  <field column="CategoryCount" columntype="integer" fieldtype="CustomUserControl" allowempty="true" system="true" publicfield="false" guid="d333614c-e26b-45fa-803f-2815644d9b6e" visibility="none" reftype="Required">
    <properties>
      <fieldcaption>CategoryEnabled</fieldcaption>
    </properties>
    <settings>
      <controlname>checkboxcontrol</controlname>
    </settings>
  </field>
  <field column="CategoryUserID" columntype="integer" fieldtype="CustomUserControl" allowempty="true" system="true" publicfield="false" guid="aebc6d41-6911-4955-8566-3e46053d2243" visibility="none" reftype="Required">
    <properties>
      <fieldcaption>CategoryUserID</fieldcaption>
    </properties>
    <settings>
      <AutoCompleteShowOnlyCurrentWordInCompletionListItem>False</AutoCompleteShowOnlyCurrentWordInCompletionListItem>
      <Trim>False</Trim>
      <AutoCompleteFirstRowSelected>False</AutoCompleteFirstRowSelected>
      <FilterMode>False</FilterMode>
      <controlname>textboxcontrol</controlname>
      <AutoCompleteEnableCaching>False</AutoCompleteEnableCaching>
    </settings>
  </field>
  <field column="CategoryGUID" columntype="guid" fieldtype="CustomUserControl" system="true" publicfield="false" guid="09d6706d-6145-400c-9e12-c47f14fdfa44" visibility="none" reftype="Required">
    <properties>
      <fieldcaption>CategoryGUID</fieldcaption>
    </properties>
    <settings>
      <controlname>LabelControl</controlname>
    </settings>
  </field>
  <field column="CategoryLastModified" columntype="datetime" fieldtype="CustomUserControl" system="true" publicfield="false" guid="67e9377c-c25a-4dd7-9ef8-9b9d97a408ce" visibility="none" reftype="Required">
    <properties>
      <fieldcaption>CategoryLastModified</fieldcaption>
    </properties>
    <settings>
      <controlname>calendarcontrol</controlname>
    </settings>
  </field>
  <field column="CategoryIDPath" columntype="text" fieldtype="CustomUserControl" allowempty="true" system="true" columnsize="450" publicfield="false" guid="aac5e74e-aa14-43b5-b18c-fd329ba7974c" visibility="none" reftype="Required">
    <properties>
      <fieldcaption>CategoryIDPath</fieldcaption>
    </properties>
    <settings>
      <AutoCompleteEnableCaching>False</AutoCompleteEnableCaching>
      <AutoCompleteShowOnlyCurrentWordInCompletionListItem>False</AutoCompleteShowOnlyCurrentWordInCompletionListItem>
      <Trim>False</Trim>
      <AutoCompleteFirstRowSelected>False</AutoCompleteFirstRowSelected>
      <controlname>textboxcontrol</controlname>
      <FilterMode>False</FilterMode>
    </settings>
  </field>
  <field column="CategoryNamePath" columntype="text" fieldtype="CustomUserControl" allowempty="true" system="true" columnsize="1500" publicfield="false" guid="1591d49a-9209-4d55-851c-9fe1769e9def" visibility="none" reftype="Required">
    <properties>
      <fieldcaption>CategoryNamePath</fieldcaption>
    </properties>
    <settings>
      <AutoCompleteShowOnlyCurrentWordInCompletionListItem>False</AutoCompleteShowOnlyCurrentWordInCompletionListItem>
      <Trim>False</Trim>
      <AutoCompleteFirstRowSelected>False</AutoCompleteFirstRowSelected>
      <FilterMode>False</FilterMode>
      <controlname>textboxcontrol</controlname>
      <AutoCompleteEnableCaching>False</AutoCompleteEnableCaching>
    </settings>
  </field>
  <field column="CategoryLevel" columntype="integer" fieldtype="CustomUserControl" allowempty="true" system="true" publicfield="false" guid="359e5923-49da-4a39-9910-b9458d5a40a2" visibility="none" reftype="Required">
    <properties>
      <fieldcaption>CategoryLevel</fieldcaption>
    </properties>
    <settings>
      <AutoCompleteEnableCaching>False</AutoCompleteEnableCaching>
      <AutoCompleteShowOnlyCurrentWordInCompletionListItem>False</AutoCompleteShowOnlyCurrentWordInCompletionListItem>
      <Trim>False</Trim>
      <AutoCompleteFirstRowSelected>False</AutoCompleteFirstRowSelected>
      <controlname>textboxcontrol</controlname>
      <FilterMode>False</FilterMode>
    </settings>
  </field>
  <field column="CategoryOrder" columntype="integer" fieldtype="CustomUserControl" allowempty="true" system="true" publicfield="false" guid="3b0a29ce-b93f-4ff8-a86b-5273a4ad1336" visibility="none" reftype="Required">
    <properties>
      <fieldcaption>CategoryOrder</fieldcaption>
    </properties>
    <settings>
      <AutoCompleteShowOnlyCurrentWordInCompletionListItem>False</AutoCompleteShowOnlyCurrentWordInCompletionListItem>
      <Trim>False</Trim>
      <AutoCompleteFirstRowSelected>False</AutoCompleteFirstRowSelected>
      <FilterMode>False</FilterMode>
      <controlname>textboxcontrol</controlname>
      <AutoCompleteEnableCaching>False</AutoCompleteEnableCaching>
    </settings>
  </field>
</form>'
WHERE [ClassName] LIKE 'cms.category'
END
GO

-- HFA-51 - Old warning message is shown for root deletion in Pages app
DECLARE @HOTFIXVERSION INT;
SET @HOTFIXVERSION = (SELECT [KeyValue] FROM [CMS_SettingsKey] WHERE [KeyName] = N'CMSHotfixVersion')
IF @HOTFIXVERSION < 3
BEGIN
	DECLARE @StringID INT;
	SET @StringID = (SELECT StringID FROM CMS_ResourceString WHERE StringKey = 'delete.rootwarning' AND StringIsCustom = 0)
	IF (@StringID > 0)
	BEGIN
		DELETE FROM CMS_ResourceTranslation WHERE TranslationStringID = @StringID
		DELETE FROM CMS_ResourceString WHERE StringID = @StringID
	END
END
GO

-- HFA-70 - Web farm servers were not removed when scaling down on Microsoft Azure
DECLARE @HOTFIXVERSION INT;
SET @HOTFIXVERSION = (SELECT [KeyValue] FROM [CMS_SettingsKey] WHERE [KeyName] = N'CMSHotfixVersion')
IF @HOTFIXVERSION < 5
BEGIN
	IF EXISTS (SELECT 1 FROM INFORMATION_SCHEMA.ROUTINES WHERE [ROUTINE_NAME]= N'Proc_CMS_WebFarmSync_SetServerTasks' AND [ROUTINE_TYPE]= N'PROCEDURE')
	BEGIN
		DROP PROCEDURE [Proc_CMS_WebFarmSync_SetServerTasks]
	END
	IF EXISTS (SELECT 1 FROM INFORMATION_SCHEMA.ROUTINES WHERE [ROUTINE_NAME]= N'Proc_CMS_WebFarmTask_UpdateTaskEnable' AND [ROUTINE_TYPE]= N'PROCEDURE')
	BEGIN
		DROP PROCEDURE [Proc_CMS_WebFarmTask_UpdateTaskEnable]
	END

	IF NOT EXISTS (SELECT 1 FROM [CMS_Query] WHERE [QueryGUID] = 'c0077aa8-23a0-47d4-a746-1391e95edb37') 
	BEGIN
		DECLARE @classID int;
		SET @classID = (SELECT TOP 1 [ClassID] FROM [CMS_Class] WHERE [ClassName] = 'cms.WebFarmServer')
		IF @classID <> 0 BEGIN
			INSERT [CMS_Query] ([QueryName], [QueryTypeID], [QueryText], [QueryRequiresTransaction], [ClassID], [QueryIsLocked], [QueryLastModified], [QueryGUID], [QueryLoadGeneration], [QueryIsCustom], [QueryConnectionString]) 
			VALUES ('delete', 1, 'Proc_CMS_WebFarmServer_Delete', 0, @classID, 0, getDate(), 'c0077aa8-23a0-47d4-a746-1391e95edb37', 0, 0, 'CMSConnectionString')
		END
	END
END
GO

ALTER PROCEDURE [Proc_CMS_WebFarmTask_Insert]
@TaskType nvarchar(50), 
@TaskTextData ntext, 
@TaskCreated datetime,
@TaskMachineName nvarchar(450),
@TaskTarget nvarchar(450),
@TaskBinary image,
@TaskIsAnonymous bit,
@TargetServerId int,
@CurrentServerId int
AS
BEGIN
	DECLARE @taskId int;
	BEGIN TRANSACTION
		INSERT INTO [CMS_WebFarmTask] ( [TaskType], [TaskTextData], [TaskBinaryData], [TaskCreated], [TaskEnabled], [TaskMachineName], [TaskTarget], [TaskIsAnonymous]) VALUES ( @TaskType, @TaskTextData, @TaskBinary, @TaskCreated, 1, @TaskMachineName, @TaskTarget, @TaskIsAnonymous ); 
		SELECT @taskId = SCOPE_IDENTITY();
	
		IF(@TaskIsAnonymous = 0) BEGIN
			IF(@TargetServerId > 0) BEGIN
				INSERT INTO [CMS_WebFarmServerTask] ( [ServerID], [TaskID] ) VALUES ( @TargetServerId, @taskId );
			END
			ELSE BEGIN
				INSERT INTO [CMS_WebFarmServerTask] ( [ServerID], [TaskID] ) SELECT ServerID, @taskId FROM [CMS_WebFarmServer] WHERE ServerID <> @CurrentServerId;
			END
		END
	COMMIT
END
GO
	
IF EXISTS (SELECT 1 FROM INFORMATION_SCHEMA.ROUTINES WHERE [ROUTINE_NAME]= N'Proc_CMS_WebFarmServer_Delete' AND [ROUTINE_TYPE]= N'PROCEDURE')
	DROP PROCEDURE [Proc_CMS_WebFarmServer_Delete]
GO
CREATE PROCEDURE [Proc_CMS_WebFarmServer_Delete] 
@ID int
AS
BEGIN
	BEGIN TRANSACTION
		-- Remove all task - server binding
		DELETE FROM [CMS_WebFarmServerTask] WHERE ServerId = @ID;
		-- Remove server
		DELETE FROM [CMS_WebFarmServer] WHERE ServerId = @ID;
	COMMIT
	-- Remove all unasigned tasks
	DELETE FROM CMS_WebFarmTask WHERE TaskEnabled = 1 AND TaskIsAnonymous = 0 AND TaskID NOT IN (SELECT TaskID FROM CMS_WebFarmServerTask);
END
GO


-- HFA-101 - form control used for Inherits from page type property in Page types application filtered data based on current site
DECLARE @HOTFIXVERSION INT;
SET @HOTFIXVERSION = (SELECT [KeyValue] FROM [CMS_SettingsKey] WHERE [KeyName] = N'CMSHotfixVersion')
IF @HOTFIXVERSION < 6
BEGIN
UPDATE [CMS_AlternativeForm]
SET [FormDefinition]='<form version="2"><category name="general.general" dummy="true" order="1"><properties><caption>{$general.general$}</caption><visible>True</visible></properties></category><field column="ClassDisplayName" order="2"><settings><ValueIsContent>False</ValueIsContent><controlname>localizabletextbox</controlname><AutoCompleteShowOnlyCurrentWordInCompletionListItem /><Trim /><AutoCompleteFirstRowSelected /><FilterMode /><AutoCompleteEnableCaching /></settings><properties><fielddescription>{$documenttype.classdisplayname.description$}</fielddescription></properties></field><field column="ClassName" order="3"><settings><ResourcePrefix>documenttype.edit</ResourcePrefix></settings><properties><fielddescription>{$documenttype.classname.description$}</fielddescription><validationerrormessage /></properties></field><field column="ClassUsesVersioning" order="4" /><field column="ClassIsDocumentType" order="5" /><field column="ClassIsCoupledClass" order="6" /><field column="ClassXmlSchema" order="7" /><field column="ClassFormDefinition" order="8" /><field column="ClassNodeNameSource" order="9" /><field column="ClassTableName" order="10"><settings><controlname>labelcontrol</controlname><AutoCompleteShowOnlyCurrentWordInCompletionListItem /><Trim /><AutoCompleteFirstRowSelected /><FilterMode /><AutoCompleteEnableCaching /></settings><properties><visiblemacro ismacro="true">{%ClassIsCoupledClass%}</visiblemacro><fielddescription>{$documenttype.classtablename.description$}</fielddescription></properties></field><field column="ClassInheritsFromClassID" visible="true" order="11"><settings><MaxDisplayedTotalItems>50</MaxDisplayedTotalItems><AllowAll>False</AllowAll><EditDialogWindowHeight>700</EditDialogWindowHeight><controlname>Uni_selector</controlname><AddGlobalObjectNamePrefix>False</AddGlobalObjectNamePrefix><ReturnColumnName>ClassID</ReturnColumnName><WhereCondition ismacro="True">ClassIsCoupledClass = 1 AND ClassID &lt;&gt; {%ClassID%} AND (ClassInheritsFromClassID IS NULL OR ClassInheritsFromClassID &lt;&gt; {%ClassID%})</WhereCondition><RemoveMultipleCommas>False</RemoveMultipleCommas><EditDialogWindowWidth>1000</EditDialogWindowWidth><AllowDefault>False</AllowDefault><DialogWindowName>SelectionDialog</DialogWindowName><MaxDisplayedItems>25</MaxDisplayedItems><ObjectType>cms.documenttype</ObjectType><LocalizeItems>True</LocalizeItems><ItemsPerPage>25</ItemsPerPage><AddGlobalObjectSuffix>False</AddGlobalObjectSuffix><UseAutocomplete>False</UseAutocomplete><EncodeOutput>True</EncodeOutput><AllowEmpty>True</AllowEmpty><DisplayNameFormat>{%ClassDisplayName%}</DisplayNameFormat><EditWindowName>EditWindow</EditWindowName><AllowEditTextBox>False</AllowEditTextBox><SelectionMode>1</SelectionMode><GlobalObjectSuffix ismacro="True">{$general.global$}</GlobalObjectSuffix><ValuesSeparator>;</ValuesSeparator><ReturnColumnType>id</ReturnColumnType></settings><properties><fielddescription>{$documenttype.classinheritsfromclassid.description$}</fielddescription><visiblemacro ismacro="true">{%ClassIsCoupledClass%}</visiblemacro><fieldcaption>{$DocumentType.InheritsFrom$}</fieldcaption></properties></field><field column="ClassIconClass" visible="true" spellcheck="false" order="12"><settings><controlname>documenttypeiconselector</controlname></settings><properties><fielddescription>{$documenttype.classicons.description$}</fielddescription><fieldcaption>{$documenttype.icon$}</fieldcaption></properties></field><category name="DocumentType.NewSettings" dummy="true" order="13"><properties><caption>{$DocumentType.NewSettings$}</caption><visible>True</visible></properties></category><field column="ClassNewPageUrl" visible="true" order="14"><settings><AutoCompleteShowOnlyCurrentWordInCompletionListItem>False</AutoCompleteShowOnlyCurrentWordInCompletionListItem><Trim>False</Trim><AutoCompleteFirstRowSelected>False</AutoCompleteFirstRowSelected><FilterMode>False</FilterMode><AutoCompleteEnableCaching>False</AutoCompleteEnableCaching></settings><properties><fielddescription>{$documenttype.classnewpageurl.description$}</fielddescription><fieldcaption>{$documenttype_edit_general.newpage$}</fieldcaption></properties></field><field column="ClassShowTemplateSelection" visible="true" hasdependingfields="true" order="15"><properties><fielddescription>{$documenttype.classshowtemplateselection.description$}</fielddescription><fieldcaption>{$DocumentType_Edit_General.TemplateSelection$}</fieldcaption></properties></field><field column="ClassPageTemplateCategoryID" visible="true" hasdependingfields="true" dependsonanotherfield="true" order="16"><settings><ShowEmptyCategories>False</ShowEmptyCategories><controlname>pagetemplatecategoryselector</controlname><WhereCondition>CategoryName != ''AdHoc'' AND CategoryPath NOT LIKE ''UITemplates%''</WhereCondition></settings><properties><visiblemacro ismacro="true">{%ClassShowTemplateSelection%}</visiblemacro><fielddescription>{$documenttype.classpagetemplatecategoryid.description$}</fielddescription><fieldcaption>{$DocumentType_Edit_General.TemplateCategorySelection$}</fieldcaption></properties></field><field column="ClassDefaultPageTemplateID" visible="true" order="17"><settings><ReturnColumnName>PageTemplateID</ReturnColumnName><RootCategoryName>/</RootCategoryName><ShowTemplateButtons>False</ShowTemplateButtons><ShowTemplates>True</ShowTemplates><ShowOnlySiteTemplates>False</ShowOnlySiteTemplates><controlname>selectpagetemplate</controlname></settings><properties><fielddescription>{$documenttype.classdefaultpagetemplateid.description$}</fielddescription><fieldcaption>{$DocumentType_Edit_General.DefaultTemplate$}</fieldcaption></properties></field><field column="ClassFormLayout" order="18" /><category name="DocumentType.EditingSettings" dummy="true" order="19"><properties><caption>{$DocumentType.EditingSettings$}</caption><visible>True</visible></properties></category><field column="ClassViewPageUrl" visible="true" order="20"><settings><AutoCompleteShowOnlyCurrentWordInCompletionListItem>False</AutoCompleteShowOnlyCurrentWordInCompletionListItem><Trim>False</Trim><AutoCompleteFirstRowSelected>False</AutoCompleteFirstRowSelected><FilterMode>False</FilterMode><AutoCompleteEnableCaching>False</AutoCompleteEnableCaching></settings><properties><fielddescription>{$documenttype.classviewpageurl.description$}</fielddescription><fieldcaption>{$DocumentType_Edit_General.ViewPage$}</fieldcaption></properties></field><field column="ClassEditingPageUrl" order="21"><settings><FilterMode>False</FilterMode></settings><properties><fielddescription>{$documenttype.classeditingpageurl.description$}</fielddescription><fieldcaption>{$DocumentType_Edit_General.EditingPage$}</fieldcaption></properties></field><field column="ClassPreviewPageUrl" visible="true" order="22"><settings><AutoCompleteShowOnlyCurrentWordInCompletionListItem>False</AutoCompleteShowOnlyCurrentWordInCompletionListItem><Trim>False</Trim><AutoCompleteFirstRowSelected>False</AutoCompleteFirstRowSelected><FilterMode>False</FilterMode><AutoCompleteEnableCaching>False</AutoCompleteEnableCaching></settings><properties><fielddescription>{$documenttype.classpreviewpageurl.description$}</fielddescription><fieldcaption>{$DocumentType_Edit_General.PreviewPage$}</fieldcaption></properties></field><field column="ClassListPageUrl" visible="true" order="23"><settings><AutoCompleteShowOnlyCurrentWordInCompletionListItem>False</AutoCompleteShowOnlyCurrentWordInCompletionListItem><Trim>False</Trim><AutoCompleteFirstRowSelected>False</AutoCompleteFirstRowSelected><FilterMode>False</FilterMode><AutoCompleteEnableCaching>False</AutoCompleteEnableCaching></settings><properties><fielddescription>{$documenttype.classlistpageurl.description$}</fielddescription><fieldcaption>{$DocumentType_Edit_General.ListPage$}</fieldcaption></properties></field><category name="documenttype.advanced" dummy="true" order="24"><properties><caption>{$documenttype.advanced$}</caption><visible>True</visible></properties></category><field column="ClassShowAsSystemTable" visible="" order="25" /><field column="ClassUsePublishFromTo" visible="true" order="26"><properties><fielddescription>{$documenttype.classusepublishfromto.description$}</fielddescription><fieldcaption>{$DocumentType_Edit_General.UsePublishFromTo$}</fieldcaption></properties></field><field column="ClassSKUMappings" order="27" /><field column="ClassIsMenuItemType" visible="true" order="28"><properties><validationerrormessage>{$sysdev.class_edit_gen.displayname$}</validationerrormessage><fielddescription>{$documenttype.classismenuitemtype.description$}</fielddescription><fieldcaption>{$DocumentType_Edit_General.IsMenuItem$}</fieldcaption></properties></field><field column="ClassNodeAliasSource" order="29" /><field column="ClassLastModified" order="30" /><field column="ClassGUID" order="31" /><field column="ClassCreateSKU" order="32" /><field column="ClassIsProduct" order="33" /><field column="ClassIsCustomTable" order="34" /><field column="ClassShowColumns" order="35" /><field column="ClassLoadGeneration" order="36"><properties><fielddescription>{$documenttype.classloadgeneration.description$}</fielddescription></properties></field><field column="ClassSearchTitleColumn" order="37" /><field column="ClassSearchContentColumn" order="38" /><field column="ClassSearchImageColumn" order="39" /><field column="ClassSearchCreationDateColumn" order="40" /><field column="ClassSearchSettings" order="41" /><field column="ClassConnectionString" visible="" order="42" /><field column="ClassSearchEnabled" order="43" /><field column="ClassSKUDefaultDepartmentName" order="44" /><field column="ClassSKUDefaultDepartmentID" order="45" /><field column="ClassContactMapping" order="46" /><field column="ClassContactOverwriteEnabled" order="47" /><field column="ClassSKUDefaultProductType" order="48" /><field column="ClassIsProductSection" order="49" /><field column="ClassFormLayoutType" order="50" /><field column="ClassVersionGUID" order="51" /><field column="ClassDefaultObjectType" order="52" /><field column="ClassIsForm" order="53" /><field column="ClassResourceID" visible="" order="54" /><field column="ClassCustomizedColumns" order="55" /><field column="ClassCodeGenerationSettings" order="56" /></form>'
WHERE [FormName] LIKE 'DocumentType'
END
GO
/* ----------------------------------------------------------------------------*/
/* This SQL command must be at the end and must contain current hotfix version */
/* ----------------------------------------------------------------------------*/
UPDATE [CMS_SettingsKey] SET KeyValue = '6' WHERE KeyName = N'CMSHotfixVersion'
GO
