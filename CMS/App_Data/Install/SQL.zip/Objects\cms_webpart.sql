CREATE TABLE [CMS_WebPart] (
		[WebPartID]                       [int] IDENTITY(1, 1) NOT NULL,
		[WebPartName]                     [nvarchar](100) NOT NULL,
		[WebPartDisplayName]              [nvarchar](100) NOT NULL,
		[WebPartDescription]              [nvarchar](max) NULL,
		[WebPartFileName]                 [nvarchar](100) NOT NULL,
		[WebPartProperties]               [nvarchar](max) NOT NULL,
		[WebPartCategoryID]               [int] NOT NULL,
		[WebPartParentID]                 [int] NULL,
		[WebPartDocumentation]            [nvarchar](max) NULL,
		[WebPartGUID]                     [uniqueidentifier] NOT NULL,
		[WebPartLastModified]             [datetime2](0) NOT NULL,
		[WebPartType]                     [int] NULL,
		[WebPartLoadGeneration]           [int] NOT NULL,
		[WebPartLastSelection]            [datetime2](0) NULL,
		[WebPartDefaultValues]            [nvarchar](max) NULL,
		[WebPartResourceID]               [int] NULL,
		[WebPartCSS]                      [nvarchar](max) NULL,
		[WebPartSkipInsertProperties]     [bit] NULL,
		[WebPartThumbnailGUID]            [uniqueidentifier] NULL,
		[WebPartDefaultConfiguration]     [nvarchar](max) NULL,
		[WebPartIconClass]                [nvarchar](200) NULL
)  
ALTER TABLE [CMS_WebPart]
	ADD
	CONSTRAINT [PK_CMS_WebPart]
	PRIMARY KEY
	NONCLUSTERED
	([WebPartID])
	
ALTER TABLE [CMS_WebPart]
	ADD
	CONSTRAINT [DEFAULT_CMS_WebPart_WebPartCategoryID]
	DEFAULT ((0)) FOR [WebPartCategoryID]
ALTER TABLE [CMS_WebPart]
	ADD
	CONSTRAINT [DEFAULT_CMS_WebPart_WebPartDisplayName]
	DEFAULT (N'') FOR [WebPartDisplayName]
ALTER TABLE [CMS_WebPart]
	ADD
	CONSTRAINT [DEFAULT_CMS_WebPart_WebPartFileName]
	DEFAULT (N'') FOR [WebPartFileName]
ALTER TABLE [CMS_WebPart]
	ADD
	CONSTRAINT [DEFAULT_CMS_WebPart_WebPartGUID]
	DEFAULT ('00000000-0000-0000-0000-000000000000') FOR [WebPartGUID]
ALTER TABLE [CMS_WebPart]
	ADD
	CONSTRAINT [DEFAULT_CMS_WebPart_WebPartLastModified]
	DEFAULT ('12/4/2013 4:51:30 PM') FOR [WebPartLastModified]
ALTER TABLE [CMS_WebPart]
	ADD
	CONSTRAINT [DEFAULT_CMS_WebPart_WebPartLoadGeneration]
	DEFAULT ((0)) FOR [WebPartLoadGeneration]
ALTER TABLE [CMS_WebPart]
	ADD
	CONSTRAINT [DEFAULT_CMS_WebPart_WebPartName]
	DEFAULT (N'') FOR [WebPartName]
ALTER TABLE [CMS_WebPart]
	ADD
	CONSTRAINT [DEFAULT_CMS_WebPart_WebPartProperties]
	DEFAULT (N'') FOR [WebPartProperties]
ALTER TABLE [CMS_WebPart]
	ADD
	CONSTRAINT [DEFAULT_CMS_WebPart_WebPartSkipInsertProperties]
	DEFAULT ((0)) FOR [WebPartSkipInsertProperties]
CREATE NONCLUSTERED INDEX [IX_CMS_WebPart_WebPartCategoryID]
	ON [CMS_WebPart] ([WebPartCategoryID]) 
CREATE NONCLUSTERED INDEX [IX_CMS_WebPart_WebPartLastSelection]
	ON [CMS_WebPart] ([WebPartLastSelection]) 
CREATE CLUSTERED INDEX [IX_CMS_WebPart_WebPartLoadGeneration]
	ON [CMS_WebPart] ([WebPartLoadGeneration]) 
CREATE NONCLUSTERED INDEX [IX_CMS_WebPart_WebPartName]
	ON [CMS_WebPart] ([WebPartName]) 
CREATE NONCLUSTERED INDEX [IX_CMS_WebPart_WebPartParentID]
	ON [CMS_WebPart] ([WebPartParentID]) 
CREATE NONCLUSTERED INDEX [IX_CMS_WebPart_WebPartResourceID]
	ON [CMS_WebPart] ([WebPartResourceID]) 

ALTER TABLE [CMS_WebPart]
	WITH NOCHECK
	ADD CONSTRAINT [FK_CMS_WebPart_WebPartCategoryID_CMS_WebPartCategory]
	FOREIGN KEY ([WebPartCategoryID]) REFERENCES [CMS_WebPartCategory] ([CategoryID])
ALTER TABLE [CMS_WebPart]
	CHECK CONSTRAINT [FK_CMS_WebPart_WebPartCategoryID_CMS_WebPartCategory]
ALTER TABLE [CMS_WebPart]
	WITH NOCHECK
	ADD CONSTRAINT [FK_CMS_WebPart_WebPartParentID_CMS_WebPart]
	FOREIGN KEY ([WebPartParentID]) REFERENCES [CMS_WebPart] ([WebPartID])
ALTER TABLE [CMS_WebPart]
	CHECK CONSTRAINT [FK_CMS_WebPart_WebPartParentID_CMS_WebPart]
ALTER TABLE [CMS_WebPart]
	WITH NOCHECK
	ADD CONSTRAINT [FK_CMS_WebPart_WebPartResourceID_CMS_Resource]
	FOREIGN KEY ([WebPartResourceID]) REFERENCES [CMS_Resource] ([ResourceID])
ALTER TABLE [CMS_WebPart]
	CHECK CONSTRAINT [FK_CMS_WebPart_WebPartResourceID_CMS_Resource]
