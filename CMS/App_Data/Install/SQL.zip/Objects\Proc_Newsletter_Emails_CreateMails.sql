CREATE PROCEDURE [Proc_Newsletter_Emails_CreateMails]
@NewsletterIssueID int,
@NewsletterID int,
@SiteID int,
@MonitoringEnabled bit,
@BounceLimit int
AS
BEGIN
SET NOCOUNT ON;
BEGIN TRANSACTION
		
IF (@MonitoringEnabled = 0)
BEGIN
	SET @BounceLimit = 0
END
-- Remove temporary table if exists
IF OBJECT_ID('tempdb..#NewsletterEmailsTempTable') IS NOT NULL
BEGIN
	DROP TABLE #NewsletterEmailsTempTable;
END;
-- Create temporary table
CREATE TABLE #NewsletterEmailsTempTable 
(
	EmailID INT IDENTITY(1,1),
	EmailNewsletterIssueID INT,
	EmailSubscriberID INT,
	EmailSiteID INT,
	EmailSending INT,
	EmailGUID uniqueidentifier,
	EmailUserID INT,
	EmailAddress NVARCHAR(200) COLLATE database_default
);
-- Create newsletter email queue items for approved and active classic subscribers
INSERT INTO #NewsletterEmailsTempTable (EmailSubscriberID, EmailAddress)
	SELECT Subscription.SubscriberID, Subscriber.SubscriberEmail
	FROM Newsletter_SubscriberNewsletter AS Subscription
		INNER JOIN
		Newsletter_Subscriber AS Subscriber ON Subscription.SubscriberID = Subscriber.SubscriberID
	WHERE (NewsletterID = @NewsletterID) AND (Subscription.SubscriptionApproved = 1 OR Subscription.SubscriptionApproved IS NULL) AND
		(Subscription.SubscriptionEnabled = 1 OR Subscription.SubscriptionEnabled IS NULL) AND
		(Subscriber.SubscriberType IS NULL) AND (Subscriber.SubscriberBounces IS NULL OR (@BounceLimit <= 0 AND Subscriber.SubscriberBounces < 2147483647) OR Subscriber.SubscriberBounces < @BounceLimit)
	ORDER BY Subscription.SubscriberID
   
-- Create newsletter email queue items for approved and active user subscribers
INSERT INTO #NewsletterEmailsTempTable (EmailSubscriberID, EmailAddress)
	SELECT Subscription.SubscriberID, CMS_User.Email
	FROM (Newsletter_SubscriberNewsletter AS Subscription INNER JOIN Newsletter_Subscriber AS Subscriber ON Subscription.SubscriberID = Subscriber.SubscriberID)
		LEFT OUTER JOIN CMS_User ON Subscriber.SubscriberRelatedID = CMS_User.UserID
	WHERE NewsletterID = @NewsletterID AND (Subscription.SubscriptionApproved = 1 OR Subscription.SubscriptionApproved IS NULL) AND
		(Subscription.SubscriptionEnabled = 1 OR Subscription.SubscriptionEnabled IS NULL) AND
		(Subscriber.SubscriberType = 'cms.user') AND (Subscriber.SubscriberBounces IS NULL OR (@BounceLimit <= 0 AND Subscriber.SubscriberBounces < 2147483647) OR Subscriber.SubscriberBounces < @BounceLimit) AND
		NOT (CMS_User.Email IS NULL OR CMS_User.Email = '')
	ORDER BY Subscription.SubscriberID
-- Create newsletter email queue items for approved and active role subscribers
INSERT INTO #NewsletterEmailsTempTable (EmailSubscriberID, EmailUserID, EmailAddress)
	SELECT Subscription.SubscriberID, UserInfo.UserID, UserInfo.Email
	FROM (Newsletter_SubscriberNewsletter AS Subscription INNER JOIN Newsletter_Subscriber AS Subscriber ON Subscription.SubscriberID = Subscriber.SubscriberID)
		LEFT OUTER JOIN
		View_CMS_UserSettingsRole_Joined AS UserInfo ON Subscriber.SubscriberRelatedID = UserInfo.RoleID
	WHERE NewsletterID = @NewsletterID AND (Subscription.SubscriptionApproved = 1 OR Subscription.SubscriptionApproved IS NULL) AND
		(Subscription.SubscriptionEnabled = 1 OR Subscription.SubscriptionEnabled IS NULL) AND
		(Subscriber.SubscriberType = 'cms.role') AND (UserInfo.UserBounces IS NULL OR (@BounceLimit <= 0 AND UserInfo.UserBounces < 2147483647) OR UserInfo.UserBounces < @BounceLimit) AND
		NOT (UserInfo.Email IS NULL OR UserInfo.Email = '')
	ORDER BY Subscription.SubscriberID
-- Remove duplicates
DELETE #NewsletterEmailsTempTable 
FROM #NewsletterEmailsTempTable
LEFT OUTER JOIN (
	SELECT MIN(EmailID) as EmailID, EmailAddress
	FROM #NewsletterEmailsTempTable 
	GROUP BY EmailAddress
) as KeepRecords ON
	#NewsletterEmailsTempTable.EmailID = KeepRecords.EmailID
WHERE KeepRecords.EmailID IS NULL
-- Insert data from temporary table to Newsletter_Emails without duplicates 
INSERT INTO Newsletter_Emails (EmailNewsletterIssueID, EmailSubscriberID, EmailSiteID, EmailSending, EmailGUID, EmailUserID, EmailAddress)
		SELECT @NewsletterIssueID, EmailSubscriberID, @SiteID, 1, NEWID(), EmailUserID, EmailAddress 
		FROM #NewsletterEmailsTempTable 
		WHERE NOT EXISTS (SELECT EmailAddress FROM Newsletter_Emails WHERE EmailAddress = #NewsletterEmailsTempTable.EmailAddress AND EmailNewsletterIssueID = @NewsletterIssueID)
-- Reset sending status so the sending may start	
UPDATE Newsletter_Emails SET EmailSending = NULL WHERE EmailNewsletterIssueID = @NewsletterIssueID
COMMIT TRANSACTION;
END
